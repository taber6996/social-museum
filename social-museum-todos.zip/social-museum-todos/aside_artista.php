<!DOCTYPE html>
<html>

<aside>
	<nav id="Menu Artista">
		<ul id="lista3">
			<li> <a href="general.php">General</a></li>
			<li> <a href="subscrpciones.php">Subscripciones</a></li>
			<li> <a href="entradas.php">Entradas</a></li>
			<li> <a href="mis_obras.php">Mis obras</a></li>
			<li> <a href="compras.php">Compras</a></li>
			<li> <a href="buzon.php">Buzón</a></li>
			<li> <a href="upload.php">Subir producto</a></li>
			<li> <a href="logout.php">Cerrar sesión</a></li>
		</ul>
	</nav>	
</aside>
	
</html>