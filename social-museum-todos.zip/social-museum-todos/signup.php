<?php 
    require_once __DIR__.'/includes/formsignup.php';
    formularioSignup();
?>