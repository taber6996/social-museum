<!DOCTYPE html>
<html>

<header>
	<section id='info usuario'> <img src='img/user.jpg' width='50px' height='50px'> 
	<?php echo $_SESSION["nombre"] ?> - <?php echo $_SESSION["rol"] ?> </section>
</header>
	
</html>