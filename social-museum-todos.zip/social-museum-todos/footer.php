<!DOCTYPE html>
<html>

<footer>
	<nav id="pie">
			<a href="sobre_nosotros.php">Sobre nosotros</a>
			<span class="separador">|</span> <a href="contacto.php">Contacto</a>
	</nav>	
</footer>
	
<html>