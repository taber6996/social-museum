<?php
  require_once __DIR__.'/includes/formUpload.php';

  formularioUpload();
?>