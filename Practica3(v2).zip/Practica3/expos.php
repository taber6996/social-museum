<?php 
	require_once __DIR__.'/includes/config.php';

	$tituloPagina = 'Expos - ';

	$contenidoPrincipal=<<<EOS
		<p>aqui se mostraran las exposiciones</p>
	EOS;

	require __DIR__.'/includes/plantillas/layout1.php';