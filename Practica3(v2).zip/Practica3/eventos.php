<?php 
require_once __DIR__.'/includes/config.php';

$tituloPagina = 'Eventos - ';

$contenidoPrincipal=<<<EOS
	<p>aqui se mostraran los eventos</p>
EOS;

require __DIR__.'/includes/plantillas/layout1.php';