<?php 
require_once __DIR__.'/includes/config.php';

$tituloPagina = '';

$contenidoPrincipal=<<<EOS
<img src="img/c1.jpg" width="75%" height="400px">
EOS;

require __DIR__.'/includes/plantillas/layout1.php';