<aside>
	<nav id="Menu Artista">
	<ul id="lista1">
		<li> <a href="general_admin.php">General</a></li>
		<li> <a href="productos.php">Subir producto</a></li>
		<li> <a href="lista_eventos.php">Crear evento</a></li>
		<li> <a href="logout.php">Cerrar sesión</a></li>
	</ul>
	</nav>	
</aside>