<aside>
	<nav id="Menu Artista">
	<ul id="lista1">
		<li> <a href="general_user.php">General</a></li>
		<li> <a href="subscrpciones.php">Subscripciones</a></li>
		<li> <a href="entradas.php">Entradas</a></li>
		<li> <a href="estudio.php">Estudio</a></li>
		<li> <a href="compras.php">Compras</a></li>
		<li> <a href="buzon.php">Buzón</a></li>
		<li> <a href="logout.php">Cerrar sesión</a></li>
	</ul>
	</nav>	
</aside>