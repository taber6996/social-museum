<?php 
require_once __DIR__.'/includes/config.php';

$tituloPagina = 'Artistas - ';

$contenidoPrincipal=<<<EOS
	<p>aqui se mostraran los artistas</p>
EOS;

require __DIR__.'/includes/plantillas/layout1.php';