<?php 
    require_once __DIR__.'/includes/formlogin.php';
   // session_start();
    formularioLogin();
?>

