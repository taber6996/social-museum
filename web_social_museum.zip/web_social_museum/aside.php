<!DOCTYPE html>
<html>

<aside>
	<nav id="Menu Principal">
		<ul id="lista1">
			<li> <img src="img/busca.jpg" width="15px" height="15px"> </li>
			<li> | <a href="artistas.php">Artistas</a></li>
			<li> | <a href="expos.php">Expos</a></li>
			<li> | <a href="tienda.php">Tienda</a></li>
			<li> | <a href="eventos.php">Eventos</a></li>
			<li> | <a href="cuenta.php">Cuenta</a></li>
			<li> | <img src="img/spain.jpg" width="15px" height="15px"> </li>
		</ul>
	</nav>	
</aside>
	
</html>