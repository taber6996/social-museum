<!DOCTYPE html>
<html>
<head>
	<title>Social Museum</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css" />
	<meta charset="UTF-8">
</head>

<body>
	<?php
	require('header.php');
	?>
	<?php
	require('aside.php');
	?>

	<main>
			<img src="img/c1.jpg" width="75%" height="400px">
	</main>
	
	<?php
	require('footer.php');
	?>
</body>

</html>